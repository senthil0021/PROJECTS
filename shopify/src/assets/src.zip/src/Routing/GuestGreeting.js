import React from 'react';

function GuestGreeting() {
  return <h1>Please sign in to continue.</h1>;
}

export default GuestGreeting;
