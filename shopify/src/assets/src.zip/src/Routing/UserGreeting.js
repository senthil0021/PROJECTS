import React from 'react';

function UserGreeting() {
  return <h1>Welcome back, User!</h1>;
}

export default UserGreeting;
